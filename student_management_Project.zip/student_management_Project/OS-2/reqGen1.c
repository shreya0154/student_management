#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>


int main() {
    srand(time(NULL));  
    int fifo_fd[2];
    pipe(fifo_fd);
    if (fifo_fd == -1) {
        perror("open");
        return 1;
    }
    int connection_status[2];
    // write(fifo_fd, "admin", strlen("admin") + 1);
    write(STDOUT_FILENO, "admin", strlen("admin") + 1);

    read(STDIN_FILENO, &connection_status[0], sizeof(connection_status));    // coming from kernel
    read(STDIN_FILENO, &connection_status[1], sizeof(connection_status));

    if (connection_status[0] == 0) {
        close(fifo_fd);
        return 1;
    }

    int num_requests = 12;
    while (num_requests--) {
        int admin_pipe[2];
        pipe(admin_pipe);
        pid_t child_pid = fork();
        //child process
        close(admin_pipe[0]);
        if(child_pid==0){
            int student_id , op_id;
            int interval = (rand() % 4) + 2; 
            int op_id = rand()%4;
            write(admin_pipe[1] ,&op_id, sizeof(op_id));
            write(admin_pipe[1], &student_id , sizeof(student_id));
            sleep(interval);
            close(admin_pipe[1]);
           
        } else {   //parent process
           int server_pipe[2];
           pipe(server_pipe);
           close(admin_pipe[1]);
           close(server_pipe[0]);
           int student_id , op_id;
           int interval = (rand() % 4) + 2; 
           int op_id = rand()%4;
           read(admin_pipe[0], &student_id, sizeof(student_id));
           read(admin_pipe[0], &op_id, sizeof(op_id));
           write(STDOUT_FILENO, &op_id, sizeof(op_id));
           write(STDOUT_FILENO, &student_id, sizeof(student_id));
           close(admin_pipe[0]);
        //    close(server_pipe[1]);


        }
    }
    close(fifo_fd);
    return 0;
}