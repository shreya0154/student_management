#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<unistd.h>
#include<pthread.h>
#include<stdbool.h>

struct studentDetails{
int student_id;
char first_name[50];
char last_name[50];
char hostel[10];
char course[10];
char dob[15];
char course_duration[15];
int roomNo;
};
typedef struct studentDetails studet;
struct list{
studet data;
struct list* next;
};
typedef struct list node;
typedef node* ptd;




ptd fetchfromDisk(FILE *disk, int student_id){
ptd new = (ptd)malloc(sizeof(node)); 
disk = fopen("disk.txt", "r");
int stringsize = 500;
new->data.student_id = student_id;
char student[stringsize]; //stringsize = 500
char studentDetail[500];
int current_line_number = 1;
while((fgets(student, 500 , disk)) != NULL){
strcpy(studentDetail, student);
char *token = strtok(student, "\t");                                     //splitting of a line of disk  
if(student_id == atoi(token)){                                           //char to int using atoi
//required student id has been found 
break;
}
else if(current_line_number < atoi(token)){
//data has been deleted and not found in disk
return NULL;
}
current_line_number ++;
}

//splitting the string using the delimiter : "\t";
char *token1 = strtok(studentDetail, "\t");                           

char details[6][50]; 
//only strings info are being stored in this char array
int i = 0; 
while(token1 != NULL && i<6){
token1 = strtok(NULL, "\t");
strcpy(details[i], token1);
i++;
}
                                 
strcpy(new->data.first_name, details[0]);
strcpy(new->data.last_name, details[1]);
strcpy(new->data.hostel, details[2]);
strcpy(new->data.course, details[3]);
strcpy(new->data.dob, details[4]);
strcpy(new->data.course_duration, details[5]);

//for fetching room no.
token1 = strtok(NULL, "\t");    
new->data.roomNo = atoi(token1); 
new->next = NULL;
return new;
}


int main(){
    int dataRequest;   // student_id of data to be fetched
    read(STDIN_FILENO, &dataRequest, sizeof(int));
    FILE *disk;
    disk = fopen("disk.txt", "r");
    ptd new = (ptd)malloc(sizeof(node));
    new = fetchfromDisk(disk , dataRequest);
    if(new != NULL){
    // write(STDOUT_FILENO, &new->data.student_id, sizeof(int));
    write(STDOUT_FILENO, new->data.first_name, sizeof(new->data.first_name));
    write(STDOUT_FILENO, &new->data.student_id, sizeof(int));
    write(STDOUT_FILENO, new->data.last_name, sizeof(new->data.last_name));
    write(STDOUT_FILENO, new->data.hostel, sizeof(new->data.hostel));
    write(STDOUT_FILENO, new->data.course, sizeof(new->data.course));
    write(STDOUT_FILENO, new->data.dob, sizeof(new->data.dob));
    write(STDOUT_FILENO, new->data.course_duration, sizeof(new->data.course_duration));
    write(STDOUT_FILENO, new->data.roomNo, sizeof(new->data.roomNo));
    }
    else{
        char notFound[15] = "notFound"
        write(STDOUT_FILENO, notFound , sizeof(notFound));
    }
    
}