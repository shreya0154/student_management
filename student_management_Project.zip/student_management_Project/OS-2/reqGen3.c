#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>

// #define FIFO_NAME "/tmp/admin_fifo"

int main() {
    srand(time(NULL));  
    int fifo_fd[2];
    pipe(fifo_fd);
    
    if (fifo_fd == -1) {
        perror("error in creating pipe");
        return 1;
    }


    int connection_status[2];
    // write(fifo_fd, "admin", strlen("admin") + 1);
    write(STDOUT_FILENO, "admin", strlen("admin") + 1);

    read(STDIN_FILENO, &connection_status[0], sizeof(connection_status));    // coming from kernel
    read(STDIN_FILENO, &connection_status[1], sizeof(connection_status));

    if (connection_status[0] == 0) {
        close(fifo_fd);
        return 1;
    }
    // int connection_status;
    // write(fifo_fd, "member", strlen("member") + 1);
    // read(fifo_fd, &connection_status, sizeof(connection_status));

    // if (connection_status == 0) {
    //     close(fifo_fd);
    //     return 1;
    // }

    int num_requests = 35;
    while (num_requests--) {
        int member_pipe[2];
        pipe(member_pipe);
        pid_t child_id = fork();
        close(member_pipe[0]);
        //child proccess
        if(child_id==0){
        int interval = 1;
        int op_id = rand()%4; 
        int student_id = ((rand()%100)+1);
        write(member_pipe[1], &op_id, sizeof(op_id));
        write(member_pipe[1], &student_id, sizeof(student_id)); 
        close(member_pipe[1]);
        sleep(interval);
        
    } else {       //parent process
        int server_pipe[2];
        pipe(member_pipe);
        close(member_pipe[1]);
        close(server_pipe[0]);
        int interval = 1;
        int op_id = rand()%4; 
        int student_id = ((rand()%100)+1);
        read(member_pipe[0], &op_id, sizeof(op_id));
        read(member_pipe[0], &student_id, sizeof(student_id));
        write(STDOUT_FILENO, &op_id , sizeof(op_id));
        write(STDOUT_FILENO, &student_id, sizeof(student_id));
        close(member_pipe[0]);
        // close(server_pipe[1]);
    }
 }

    close(fifo_fd);
    return 0;
}