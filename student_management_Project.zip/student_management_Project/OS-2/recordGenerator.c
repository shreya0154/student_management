#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
//include all required header files


struct studentDetails{
int student_id;
char first_name[50];
char last_name[50];
char hostel[10];
char course[10];
char dob[15];
char course_duration[15];
int roomNo;
};
typedef struct studentDetails studet;
struct list{
studet data;
struct list* next;
};
typedef struct list node;
typedef node* ptd;







void registration(FILE *firstnames, FILE *lastnames, FILE *hostel, FILE *courses, int student_id){
FILE *disk;
firstnames = fopen("firstnames.txt", "r");
lastnames = fopen("lastnames.txt", "r");
hostel = fopen("hostel.txt", "r");
courses = fopen("courses.txt", "r");
disk = fopen("disk.txt", "a");
int stringsize = 50;
int arraysize = 4;
char student[arraysize][stringsize]; 
//for(int i = 0; i<arraysize; i++){
int current_line_number = 0;

//choosing random line for random selection of details
int line_firstnames = (rand()%20), line_lastnames = (rand()%20), line_hostel = (rand()%5), line_courses = (rand()%5);

while((fscanf(firstnames, "%s", student[0])) != EOF){
    if (current_line_number == line_firstnames){
        //pointer is reached randomly chosen line
        break;
    }
current_line_number ++;
} 

current_line_number = 0;


while((fscanf(lastnames, "%s", student[1])) != EOF){
    if (current_line_number == line_lastnames){
        //pointer is reached randomly chosen line
        break;
    }
current_line_number ++;
} 

current_line_number = 0;


while((fscanf(hostel, "%s", student[2])) != EOF){
    if (current_line_number == line_hostel){
        //pointer is reached randomly chosen line
        break;
    }
current_line_number ++;
} 

current_line_number = 0;

while((fscanf(courses, "%s", student[3])) != EOF){
    if (current_line_number == line_courses){
        //pointer is reached randomly chosen line
        break;
    }
current_line_number ++;
} 

//write student id in disk
fprintf(disk, "%d\t" , student_id); 

//write string type details taken from different files
for(int i = 0 ; i<arraysize ; i++){
fprintf(disk, "%s\t" , student[i]);
}

//now generate and writing random dob(dd.mm.yyyy), duration of course, room no.
if((strcmp(student[3], "BTech.")) == 0){
    fprintf(disk, "%d", ((rand()%30)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%12)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%6)+2001));
    fputc('\t' , disk);
    fputs("4years", disk);             
    fputc('\t', disk);
    //room no.
    fprintf(disk, "%d", ((rand()%200)+101));
}

 if(strcmp(student[3] , "MTech.") == 0 || strcmp(student[3] , "MBA") == 0 || strcmp(student[3] , "MS") == 0 ){
    fprintf(disk, "%d", ((rand()%30)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%12)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%6)+1997));
    fputc('\t' , disk);
    fputs("2years", disk);
    fputc('\t', disk);
    fprintf(disk, "%d", ((rand()%100)+301));
   }


if(strcmp(student[3] , "PhD") == 0){
    fprintf(disk, "%d", ((rand()%30)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%12)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%6)+1992));
    fputc('\t' , disk);
    fputs("5years", disk);
    fputc('\t', disk);
    fprintf(disk, "%d", ((rand()%100)+401));
}

fputc('\n', disk);
fclose(firstnames);
fclose(lastnames);
fclose(hostel);
fclose(courses);
fclose(disk);
}


int main(){
FILE *firstnames , *lastnames , *hostel , *courses , *disk;
//registering 100 students initially
int count = 1, student_id;
while(count<=100){
student_id = count;
registration(firstnames, lastnames, hostel, courses, student_id);
count++;
}
return 0; 
}