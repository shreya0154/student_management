#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
//include all required header files


struct studentDetails{
int student_id;
char first_name[50];
char last_name[50];
char hostel[10];
char course[10];
char dob[15];
char course_duration[15];
int roomNo;
};
typedef struct studentDetails studet;
struct list{
studet data;
struct list* next;
};
typedef struct list node;
typedef node* ptd;



int main(){
    int pipe_fd[2];
    int pipe_disk[2];
    int record_pipe[2];
    int request1_pipe[2];
    int request2_pipe[2];
    int request3_pipe[2];
    int datarequest1[2];
    int datarequest2[2];
    int datarequest3[2];
    pipe(pipe_fd);
    pipe(pipe_disk);
    pipe(record_pipe);
    pipe(request1_pipe);
    pipe(request2_pipe);
    pipe(request3_pipe);
    pipe(datarequest1);
    pipe(datarequest2);
    pipe(datarequest3);
    //check whether pipe is created or not
    int pid = fork();
    

    if (pid < 0) {
        perror("Fork failed");
        return 1;
    } else if (pid == 0) {
        // after receiving connection request
        // load server using execl
        // This code will be executed by the child process
        dup2(pipe_fd[0], STDIN_FILENO);
        dup2(pipe_fd[1], STDOUT_FILENO);
        // Execute the child program using execl
        execl("./os_assignment_server", "os_assignment_server", NULL);
        
        // If execl fails, the code below will be executed (only if execl fails)
        perror("Exec failed");
        return 1;
    } else {
        // This code will be executed by the parent process
        //printf("Parent process: PID = %d\n", getpid());
        // char connectionSignal[10];
        int connectionSignal[2];
        read(pipe_fd[0], connectionSignal[0] , sizeof(connectionSignal));
        read(pipe_fd[0], connectionSignal[1] , sizeof(connectionSignal));


        int pid2 = fork();
        if(pid2 == 0){
            //child process
            if(connectionSignal[0] != 0){
            dup2(record_pipe[0], STDIN_FILENO);
            dup2(record_pipe[1], STDOUT_FILENO);
            // connection is successfully made
            // give successful signal to generators
            write(record_pipe[1], connectionSignal[0], sizeof(connectionSignal));
            write(record_pipe[1], connectionSignal[1], sizeof(connectionSignal));
            
            // load record generators
            execl("./recordGenerator", "recordGenerator", (char*) NULL);
             perror("Exec failed");
            return 2;
        }
        }
        else{
            int pid3 = fork();
            if(pid3 == 0){
                // child process
            
                if(connectionSignal[0] != 0){
                dup2(datarequest1[0], STDIN_FILENO);
                dup2(request1_pipe[1], STDOUT_FILENO);
             int pid6 = fork();
            if(pid6 == 0){
                // connection is successfully made
            // give successful signal to generators
                write(request1_pipe[1], connectionSignal[0], sizeof(connectionSignal));
            write(request1_pipe[1], connectionSignal[1], sizeof(connectionSignal));
           
            // load record generators
            execl("./reqGen1", "reqGen1", (char*) NULL);
             perror("Exec failed");
             return 3;
            }
            else{
                close(datarequest1[1]);
                close(pipe_fd[0]);
                int data1[2];
                // read request data from generators
                read(datarequest1[0], &data1[0], sizeof(int));
                read(datarequest1[0], &data1[1], sizeof(int));
               
                // write request data to server
                write(pipe_fd[1], &data1, sizeof(data1));
            }
            
        }
            }
            else{
                pid4 = fork();
                if(pid4 == 0){
                // child process
                if(connectionSignal[0] != 0){
                dup2(datarequest2[0], STDIN_FILENO);
                dup2(request2_pipe[1], STDOUT_FILENO);
            int pid7 = fork();
            if(pid7 == 0){
                 // connection is successfully made
            // give successful signal to generators
               write(request2_pipe[1], connectionSignal[0], sizeof(connectionSignal));
            write(request2_pipe[1], connectionSignal[1], sizeof(connectionSignal));
            
            // load record generators
            execl("./reqGen2", "reqGen2", (char*) NULL);
             perror("Exec failed");
        return 4;
            }
            else{
                close(datarequest2[1]);
                close(pipe_fd[0]);
                int data2[2];
                // read request data from generators
                read(datarequest2[0], &data2[0], sizeof(int));
                read(datarequest2[0], &data2[1], sizeof(int));
               
                // write request data to server
                write(pipe_fd[1], &data2, sizeof(data2));
            }
           
        }
            }
            else{
                pid5 = fork();
                if(pid5 == 0){
                // child process
                if(connectionSignal[0] != 0){
                dup2(datarequest3[0], STDIN_FILENO);
                dup2(request3_pipe[1], STDOUT_FILENO);
             int pid8 = fork();
            if(pid8 == 0){
                // connection is successfully made
            // give successful signal to generators
                write(request3_pipe[1], connectionSignal[0], sizeof(connectionSignal));
            write(request3_pipe[1], connectionSignal[1], sizeof(connectionSignal));
            
            // load record generators
            execl("./reqGen3", "reqGen3", (char*) NULL);
             perror("Exec failed");
        return 5;
            }
            else{
                int data3[2];
                close(datarequest3[1]);
                close(pipe_fd[0]);
                // read request data from generators
                read(datarequest3[0], &data3[0], sizeof(int));
                read(datarequest3[0], &data3[1], sizeof(int));
               
                // write request data to server
                write(pipe_fd[1], &data3, sizeof(data3));
            }
            
        }
            }
            else{
                    // another child parent
                    // do parent work
                    char signalFromServer[50];
                    ssize_t bytesRead;
                    while ((bytesRead = read(pipe_fd[0], signalFromServer, sizeof(signalFromServer) - 1)) > 0) {
                    signalFromServer[bytesRead] = '\0';  // Null-terminate the string

                    if (strcmp(signalFromServer, "search in disk") == 0) {
                        //open disk and write the data in pipe to server 
                        pid_t disk = fork();
                        if(disk == 0){
                            // child process
                            // open disk
                            // FILE *diskRequest = fopen("diskRequest.txt", "w"); 
                            dup2(pipe_disk[0], STDIN_FILENO);
                            dup2(pipe_disk[1], STDOUT_FILENO);
                            // Execute the child program using execl
                            execl("./os_assignment_disk", "os_assignment_disk", NULL);
        
                            // If execl fails, the code below will be executed (only if execl fails)
                            perror("Exec failed");
                            return 6;
                            
                    
                        }
                        else{
                            // disk child parent
                            int dataRequest ; // student_id of requested data
                            read(pipe_fd[0], &dataRequest, sizeof(int));
                            ptd new = (ptd)malloc(sizeof(node));
                            
                            write(pipe_disk[1], &dataRequest, sizeof(int));
                            
                            read(pipe_disk[0], new->data.first_name, sizeof(new->data.first_name));
                            char notFound[15] = "notFound" ; 
                            if(strcmp(new->data.first_name , notFound)==0){
                                write(pipe_fd[1], notFound, sizeof(notFound));
                            }
                            else{
                            read(pipe_disk[0], &new->data.student_id, sizeof(int));
                            //read(pipe_disk[0], new->data.first_name, sizeof(new->data.first_name));
                            read(pipe_disk[0], new->data.last_name, sizeof(new->data.last_name));
                            read(pipe_disk[0], new->data.hostel, sizeof(new->data.hostel));
                            read(pipe_disk[0], new->data.course, sizeof(new->data.course));
                            read(pipe_disk[0], new->data.dob, sizeof(new->data.dob));
                            read(pipe_disk[0], new->data.course_duration, sizeof(new->data.course_duration));
                            read(pipe_disk[0], new->data.roomNo, sizeof(new->data.roomNo));

                            // read the data and then send it to server
                            write(pipe_fd[1], new->data.first_name, sizeof(new->data.first_name));
                            write(pipe_fd[1], &new->data.student_id, sizeof(int));
                            //write(pipe_fd[1], new->data.first_name, sizeof(new->data.first_name));
                            write(pipe_fd[1], new->data.last_name, sizeof(new->data.last_name));
                            write(pipe_fd[1], new->data.hostel, sizeof(new->data.hostel));
                            write(pipe_fd[1], new->data.course, sizeof(new->data.course));
                            write(pipe_fd[1], new->data.dob, sizeof(new->data.dob));
                            write(pipe_fd[1], new->data.course_duration, sizeof(new->data.course_duration));
                            write(pipe_fd[1], new->data.roomNo, sizeof(new->data.roomNo));
                        }

                        }
                    }
                        
                    }
                }
            
            }
            }

    }
    }


    return 0;
}
   


// make sure the data type of pipe and fork is correct


