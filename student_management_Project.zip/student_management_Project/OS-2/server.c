#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <dlfcn.h>
//include required header files



struct studentDetails{
int student_id;
char first_name[50];
char last_name[50];
char hostel[10];
char course[10];
char dob[15];
char course_duration[15];
int roomNo;
};
typedef struct studentDetails studet;

struct list{
studet data;
struct list* next;
};
typedef struct list node;
typedef node* ptd;


struct requestDetails{
    int student_id;
    int op_id;
    int service_id;
    int state_id;
};
typedef struct requestDetails requestDetails;

struct queuelist{
// int student_id;
// int op_id;
// int service_id;
// int state_id;
requestDetails reqdata;
struct queuelist *nextptr;
};
typedef struct queuelist queuelist;
typedef queuelist* qptr;



ptd mainmemory(ptd head, ptd new, int op_id, int student_id, FILE *disk, FILE *outputFile){
disk = fopen("disk.txt", "r");
outputFile = fopen("outputFile.txt" , "a");

when linked list is empty
if(head == NULL){
head = new;
//data not found in disk
if(head == NULL){
char msg[] = "data not found";
fputs(msg, outputFile);
return head;
}

return head;
}


//when linked list is having atleast one node
ptd ptr = (ptd)malloc(sizeof(node));
ptr = head;
int count = 0;
while(ptr != NULL){
if(ptr->data.student_id != student_id){
ptr = ptr->next;
count++;
}
else if(ptr->data.student_id == student_id){
count++;
break;
}
}


//addition of new node when no. of nodes < 5
if(count<5 && ptr == NULL){
// ptd new = (ptd)malloc(sizeof(node)); 
// new = fetchfromDisk(disk, student_id);
if(new == NULL){
char msg[] = "data not found";
fputs(msg, outputFile);
return head;
}
new->next = head;
head = new;
free(new);
return head;
}


if(count<=5 && ptr != NULL){
//node of same student id has been found in linked list(main memory)
return head;
}


//linked list is having 5 nodes
if(count == 5 && ptr == NULL){
// ptd new = (ptd)malloc(sizeof(node));
// //check whether the data is present in database or not
// new = fetchfromDisk(disk, student_id);
if(new == NULL){
    //data not found in disk
   char msg[] = "data not found";
   fputs(msg, outputFile);
   return head;
}


//data found in disk
//delete one node and add another with different student id

//deleting from the end
ptr = head;
while(ptr->next->next != NULL){
ptr = ptr->next;
}
free(ptr->next);
ptr->next = NULL;

//adding at the beginning
new->next = head;
head = new;
return head;
}
}






void registration(FILE *firstnames, FILE *lastnames, FILE *hostel, FILE *courses, int student_id){
FILE *disk;
firstnames = fopen("firstnames.txt", "r");
lastnames = fopen("lastnames.txt", "r");
hostel = fopen("hostel.txt", "r");
courses = fopen("courses.txt", "r");
disk = fopen("disk.txt", "a");
int stringsize = 50;
int arraysize = 4;
char student[arraysize][stringsize]; 
//for(int i = 0; i<arraysize; i++){
int current_line_number = 0;

//choosing random line for random selection of details
int line_firstnames = (rand()%20), line_lastnames = (rand()%20), line_hostel = (rand()%5), line_courses = (rand()%5);

while((fscanf(firstnames, "%s", student[0])) != EOF){
    if (current_line_number == line_firstnames){
        //pointer is reached randomly chosen line
        break;
    }
current_line_number ++;
} 

current_line_number = 0;


while((fscanf(lastnames, "%s", student[1])) != EOF){
    if (current_line_number == line_lastnames){
        //pointer is reached randomly chosen line
        break;
    }
current_line_number ++;
} 

current_line_number = 0;


while((fscanf(hostel, "%s", student[2])) != EOF){
    if (current_line_number == line_hostel){
        //pointer is reached randomly chosen line
        break;
    }
current_line_number ++;
} 

current_line_number = 0;

while((fscanf(courses, "%s", student[3])) != EOF){
    if (current_line_number == line_courses){
        //pointer is reached randomly chosen line
        break;
    }
current_line_number ++;
} 

//write student id in disk
fprintf(disk, "%d\t" , student_id); 

//write string type details taken from different files
for(int i = 0 ; i<arraysize ; i++){
fprintf(disk, "%s\t" , student[i]);
}

//now generate and writing random dob(dd.mm.yyyy), duration of course, room no.
if((strcmp(student[3], "BTech.")) == 0){
    fprintf(disk, "%d", ((rand()%30)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%12)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%6)+2001));
    fputc('\t' , disk);
    fputs("4years", disk);             
    fputc('\t', disk);
    //room no.
    fprintf(disk, "%d", ((rand()%200)+101));
}

 if(strcmp(student[3] , "MTech.") == 0 || strcmp(student[3] , "MBA") == 0 || strcmp(student[3] , "MS") == 0 ){
    fprintf(disk, "%d", ((rand()%30)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%12)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%6)+1997));
    fputc('\t' , disk);
    fputs("2years", disk);
    fputc('\t', disk);
    fprintf(disk, "%d", ((rand()%100)+301));
   }


if(strcmp(student[3] , "PhD") == 0){
    fprintf(disk, "%d", ((rand()%30)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%12)+1));
    fputc('.' , disk);
    fprintf(disk, "%d", ((rand()%6)+1992));
    fputc('\t' , disk);
    fputs("5years", disk);
    fputc('\t', disk);
    fprintf(disk, "%d", ((rand()%100)+401));
}

fputc('\n', disk);
fclose(firstnames);
fclose(lastnames);
fclose(hostel);
fclose(courses);
fclose(disk);
}



bool search(ptd head, int student_id){
ptd ptr = (ptd)malloc(sizeof(node));
ptr = head;
while(ptr != NULL){
if(ptr->data.student_id == student_id){
return true;
}
else{
ptr = ptr->next;
}
}
return false;
}


void delete(ptd head, int student_id, FILE *disk){
char studentDetail[500];
char *filename = "disk.txt";
disk = fopen("disk.txt", "r");
// Temporary file to write modified content
FILE *output = fopen("temp.txt", "a"); 

if (disk == NULL || output == NULL) {
perror("File opening failed");
exit(EXIT_FAILURE);
}
char buffer[500]; 
int current_line = 0;
// while (fgets(buffer, sizeof(buffer), disk) != NULL) {
// current_line++;

while((fgets(buffer, 500 , disk))!= NULL){
strcpy(studentDetail, buffer);
current_line ++;
//first word of line is student_id in disk file
char *token = strtok(buffer, "\t"); 
if(atoi(token) != student_id){
//copying data of other students in temp file
fputs(studentDetail, output);
}
}
fclose(disk);
fclose(output);

// Replace the original file with modified content
remove(filename);
rename("temp.txt", filename);
}




bool server(int runreq[4], ptd head, clock_t *time){
// FILE *queuefile;
// queuefile = fopen(filename, "r");
int stid = runreq[0];
int opid = runreq[1];
ptd nullnode = (ptd)malloc(sizeof(node));
nullnode = NULL;
FILE *outputFile = fopen("outputFile.txt" , "a");
FILE *disk ;
int stringsize = 100;
char request[stringsize]; 

bool presenceInMM = search(head, stid);
if(presenceInMM == false)
return false;

clock_t start_time = clock();

double elapsed_time ;


if(opid == 0){
//call registration function
FILE *firstnames; FILE *lastnames; FILE *hostel; FILE *courses;
registration(firstnames, lastnames, hostel, courses, stid);
//write in the output file
elapsed_time = (double)(clock() - start_time + *time) / CLOCKS_PER_SEC;
fprintf(outputFile, "%d has been registered via %s request_generator at %.6f\n", stid, request_type, elapsed_time);
//head = mainmemory(head, nullnode, 0 , stid , disk, outputFile);
}

else if(opid == 1 ){ 
//call search function
bool searching = search(head, stid);
//write in output file
elapsed_time = (double)(clock() - start_time + *time) / CLOCKS_PER_SEC;
fprintf(outputFile, "%d is searched via %s request_generator at %.6f\n", stid, request_type, elapsed_time);

}

else if(opid == 2){

//write in output file
elapsed_time = (double)(clock() - start_time + *time) / CLOCKS_PER_SEC;
fprintf(outputFile, "%d has been updated via %s request_generator at %.6f\n", stid, request_type, elapsed_time);
}

else if(opid == 3){
//call delete function
delete(head, stid, disk);
//write in output file
elapsed_time = (double)(clock() - start_time + *time) / CLOCKS_PER_SEC;
fprintf(outputFile, "%d has been deleted via %s request_generator at %.6f\n", stid, request_type, elapsed_time);
}
return true;
//}
}





int main(int argc, char *argv){
    int read_pipe[2], write_pipe[2], status_pipe[2], requestFromGen[2];
    pipe(read_pipe);
    pipe(write_pipe);
    pipe(status_pipe);
    pipe(requestFromGen);
    char connectionRequest[15];
    // read request from kernel to make connection with generators
    read(STDIN_FILENO, connectionRequest, sizeof(connectionRequest));
     
    // char *buffer = "1,2";                                   // for positive signal to kernel
    int buffer[2];
    buffer[0] = 1;
    buffer[1] = 2;
    write(STDOUT_FILENO, buffer[0], strlen(buffer) + 1); 
    write(STDOUT_FILENO, buffer[1], strlen(buffer) + 1); 
  
        pid_t pid1 = fork();
        
        if(pid1 == 0){
            // child process
            close(write_pipe[1]);
            close(read_pipe[0]);
            char buffer2[100];
            int service_id, state_id;
            service_id = 1;
            // for reading requests
            // coming from generators via kernel
            read(STDIN_FILENO, buffer2, sizeof(buffer2));           

            if (strcmp(buffer2, "exit\n") == 0)
                break;
            
            sscanf(buffer2, "%d %d", op_id, student_id);
            qptr new = (qptr)malloc(sizeof(queuelist));
            qptr head = (qptr)malloc(sizeof(queuelist));
            head->reqdata.student_id = student_id;
            head->reqdata.op_id = op_id;
            head->reqdata.service_id = service_id; 
            head->reqdata.state_id = 0;   //ready state
            head->nextptr = NULL;
            new = head;
            int totalRequest = 62;

            while(totalRequest--) {                                            
            read(STDIN_FILENO, buffer2, sizeof(buffer2));
            if (strcmp(buffer2, "exit\n") == 0)
                break;
            service_id++;
            sscanf(buffer2, "%d %d", op_id, student_id);
            qptr ptr = (qptr)malloc(sizeof(queuelist));
            ptr->reqdata.student_id = student_id;
            ptr->reqdata.op_id = op_id;
            ptr->reqdata.service_id = service_id;
            ptr->reqdata.state_id = 0;     // ready state
            ptr->nextptr = NULL;
            new->nextptr = ptr;
            new = ptr;
            // send the request at first place to the parent process
            // place others in ready state
        }
        int totalRequest = 62;
        while(totalRequest--){
        char signal[5];
        read(write_pipe[0], signal, sizeof(signal));
        //signal from parent process to get new request to be processed
        if(strcmp(signal, "newreq") == 0){      
            // send the head node through read_pipe
            qptr send_node = (qptr)malloc(sizeof(queuelist));
            send_node = head;
        head = head->nextptr;
        int request_to_send[4];
        request_to_send[0] = send_node->reqdata.student_id;
        request_to_send[1] = send_node->reqdata.op_id;
        request_to_send[2] = send_node->reqdata.service_id;
        request_to_send[3] = 1;   // running state
        write(read_pipe[1], request_to_send, sizeof(request_to_send));
        
        }
        else if(strcmp(signal, "blocked") == 0){
            head->reqdata.state_id = 2 ;  //blocked

        }

        }
            
        }
        else{
            // parent process
            int totalReq = 62;
            int runreq[4];
            close(read_pipe[1]);
            close(write_pipe[0]);
            clock_t start_time = clock();
            // parent process
            ptd headOfMM = (ptd)malloc(sizeof(node));
            headOfMM = NULL;
            
            while((totalReq) --){
            // char *runreq;
            read(read_pipe[0], runreq, sizeof(runreq));

            // search in main memory
            bool presenceInMM = server(runreq[0], headOfMM, &start_time);
            FILE *disk;
            FILE *outputFile = fopen("outputFile.txt" , "a");
            if(presenceInMM == false){
            char signalTochild[50] = "blocked";
            write(write_pipe[1], signalTochild, sizeof(signalTochild));
            char signalToKernel[50] = "search in disk";
            write(STDOUT_FILENO, signalToKernel, sizeof(signalToKernel));
            write(STDOUT_FILENO, runreq[0], sizeof(int));
            
            ptd new = (ptd)malloc(sizeof(node));
            
            read(STDIN_FILENO, new->data.first_name, sizeof(new->data.first_name));
            if(strcmp(new->data.first_name , notFound)==0){
                new = NULL;
                char msg[] = "data not found";
                fputs(msg, outputFile);
                // data not found in disk  
            }

            else{
            read(STDIN_FILENO, &new->data.student_id, sizeof(int));
            read(STDIN_FILENO, new->data.last_name, sizeof(new->data.last_name));
            read(STDIN_FILENO, new->data.hostel, sizeof(new->data.hostel));
            read(STDIN_FILENO, new->data.course, sizeof(new->data.course));
            read(STDIN_FILENO, new->data.dob, sizeof(new->data.dob));
            read(STDIN_FILENO, new->data.course_duration, sizeof(new->data.course_duration));
            read(STDIN_FILENO, new->data.roomNo, sizeof(new->data.roomNo));
            new->next = NULL;
            }
            // send this node to main memory to add this one
            FILE *disk;
            FILE *outputFile;
            headOfMM = mainmemory(headOfMM, new, runreq[1], runreq[0], disk, outputFile);
            //ptd head, int op_id, int student_id, FILE *disk, FILE *outputFile
            char unblockedTochild[50] = "newreq";
            write(write_pipe[1], unblockedTochild, sizeof(signalTochild));
            }

            // present in main memory
            else if(presenceInMM == true){
           
            char signalTochild[50] = "newreq";
            write(write_pipe[1], signalTochild, sizeof(signalTochild));
            }
     
            // send signal to child for sending request
            }
        }
   
}









// running = 1
// ready = 0
// blocked = 2