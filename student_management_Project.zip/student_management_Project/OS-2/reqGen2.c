#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>

#define FIFO_NAME "/tmp/admin_fifo"

int main() {
    srand(time(NULL));  
    int fifo_fd[2];
    pipe(fifo_fd);
    if (fifo_fd == -1) {
        perror("open");
        return 1;
    }

    int connection_status[2];
    // write(fifo_fd, "admin", strlen("admin") + 1);
    write(STDOUT_FILENO, "admin", strlen("admin") + 1);

    read(STDIN_FILENO, &connection_status[0], sizeof(connection_status));    // coming from kernel
    read(STDIN_FILENO, &connection_status[1], sizeof(connection_status));

    if (connection_status[0] == 0) {
        close(fifo_fd);
        return 1;
    }

    

    
    int num_requests = 15;
    while (num_requests--) {
        int manager_pipe[2];
        pipe(manager_pipe);
        pid_t child_pid = fork();
        close(manager_pipe[0]);
        if(child_pid==0){ //child proccess
        //int student_id ,op_id;
        int interval = rand() % 4 + 1;
        int op_id = rand()%4;  
        int student_id = ((rand()%100)+1);
        write(manager_pipe[1], &op_id, sizeof(op_id));
        write(manager_pipe[1], &student_id, sizeof(student_id));
        close(manager_pipe[1]);
        sleep(interval);

    } else {      //parent proccess
        int server_pipe[2];
        pipe(server_pipe);
        close(manager_pipe[1]);
        close(server_pipe[0]);
        int interval = rand() % 4 + 1;
        int op_id = rand()%4;  
        int student_id = ((rand()%100)+1);
        read(manager_pipe[0], &op_id, sizeof(op_id));
        read(manager_pipe[0], &student_id, sizeof(student_id));
        write(STDOUT_FILENO , &op_id, sizeof(op_id));
        write(STDOUT_FILENO, &student_id, sizeof(student_id));
        close(manager_pipe[0]);
        // close(server_pipe[1]);

    }
        
        
        // Send request data to the server
        write(fifo_fd, &num_requests, sizeof(num_requests));
       
       
    }

    close(fifo_fd);

    return 0;
}